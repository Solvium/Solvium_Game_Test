--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE IF EXISTS "prisma_migrate_shadow_db_f1a1d2a4-d1e3-4e62-873f-467fb265a3d6";
DROP DATABASE IF EXISTS "solvium_game";




--
--


--
--

--
-- Database "prisma_migrate_shadow_db_f1a1d2a4-d1e3-4e62-873f-467fb265a3d6" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg120+2)
-- Dumped by pg_dump version 16.4 (Debian 16.4-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: prisma_migrate_shadow_db_f1a1d2a4-d1e3-4e62-873f-467fb265a3d6; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "prisma_migrate_shadow_db_f1a1d2a4-d1e3-4e62-873f-467fb265a3d6" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF8';


\connect -reuse-previous=on "dbname='prisma_migrate_shadow_db_f1a1d2a4-d1e3-4e62-873f-467fb265a3d6'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- PostgreSQL database dump complete
--

--
-- Database "solvium_game" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg120+2)
-- Dumped by pg_dump version 16.4 (Debian 16.4-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: solvium_game; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "solvium_game" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF8';


\connect "solvium_game"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: solvium_game; Type: DATABASE PROPERTIES; Schema: -; Owner: -
--

ALTER DATABASE "solvium_game" SET "TimeZone" TO 'utc';


\connect "solvium_game"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: Task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."Task" (
    "id" integer NOT NULL,
    "name" "text" NOT NULL,
    "points" integer NOT NULL,
    "link" "text",
    "isCompleted" boolean DEFAULT false NOT NULL
);


--
-- Name: Task_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."Task_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."Task_id_seq" OWNED BY "public"."Task"."id";


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."User" (
    "id" integer NOT NULL,
    "username" "text" NOT NULL,
    "name" "text",
    "referredBy" "text" NOT NULL,
    "referralCount" integer DEFAULT 0 NOT NULL,
    "chatId" integer DEFAULT 0 NOT NULL,
    "claimCount" integer DEFAULT 0 NOT NULL,
    "totalPoints" integer DEFAULT 0 NOT NULL,
    "isOfficial" boolean DEFAULT false NOT NULL,
    "isPremium" boolean DEFAULT false NOT NULL,
    "lastClaim" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: UserTask; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."UserTask" (
    "id" integer NOT NULL,
    "userId" integer NOT NULL,
    "taskId" integer NOT NULL,
    "isCompleted" boolean DEFAULT false NOT NULL
);


--
-- Name: UserTask_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."UserTask_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: UserTask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."UserTask_id_seq" OWNED BY "public"."UserTask"."id";


--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."User_id_seq" OWNED BY "public"."User"."id";


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."_prisma_migrations" (
    "id" character varying(36) NOT NULL,
    "checksum" character varying(64) NOT NULL,
    "finished_at" timestamp with time zone,
    "migration_name" character varying(255) NOT NULL,
    "logs" "text",
    "rolled_back_at" timestamp with time zone,
    "started_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "applied_steps_count" integer DEFAULT 0 NOT NULL
);


--
-- Name: Task id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."Task" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."Task_id_seq"'::"regclass");


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."User" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."User_id_seq"'::"regclass");


--
-- Name: UserTask id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."UserTask" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."UserTask_id_seq"'::"regclass");


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."Task" ("id", "name", "points", "link", "isCompleted") FROM stdin;
1	Follow X	20000	https://x.com/Solvium_game	f
2	Follow Youtube	20000	https://www.youtube.com/@solvium_puzzle	f
3	Follow Facebook	20000	https://www.facebook.com/profile.php?id=61566560151625&mibextid=LQQJ4d	f
4	Join Solvium Telegram Group	20000	https://t.me/solvium_puzzle	f
5	Join Solvium Chat	20000	https://t.me/solviumupdate	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."User" ("id", "username", "name", "referredBy", "referralCount", "chatId", "claimCount", "totalPoints", "isOfficial", "isPremium", "lastClaim") FROM stdin;
6	Ajemark	Mark Ajekevwoda	Ajemark	0	1870013901	0	120000	f	f	2024-09-30 21:53:39.634
9	Papelsneh	💠Fidelis $X 	israel_igboze	0	1615955996	0	100000	f	f	2024-10-17 07:17:58.122
7	israel_igboze	Igboze undefined	Ajemark	0	0	0	120000	f	t	2024-10-01 08:39:35.535
10	McClins	🆑int🅾️n 💠 $X 	israel_igboze	0	1066730896	0	20000	f	f	2024-10-18 08:37:05.744
\.


--
-- Data for Name: UserTask; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."UserTask" ("id", "userId", "taskId", "isCompleted") FROM stdin;
18	6	1	f
19	6	2	f
20	7	5	f
21	6	5	t
22	7	1	t
25	9	1	t
26	9	2	t
27	9	3	t
28	9	4	t
29	9	5	t
23	7	2	t
24	7	3	t
30	7	4	f
31	10	1	t
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."_prisma_migrations" ("id", "checksum", "finished_at", "migration_name", "logs", "rolled_back_at", "started_at", "applied_steps_count") FROM stdin;
1c2001f8-d1d8-4b50-8ef0-a33138f3f1b1	231f6c3209edf6e404a9c8470e9d555d2beeec021a3833599997156e1254f69e	2024-09-30 20:59:35.680903+00	20240930205928_init	\N	\N	2024-09-30 20:59:30.152539+00	1
b097bf2b-fc53-4148-bf37-16678bd0e662	df589bcf3b17214e2357ccf9ea258f10ada80d7f5f7c4ac4aced5674e262bb76	2024-10-03 10:24:13.528972+00	20241003102409_removed_category	\N	\N	2024-10-03 10:24:11.998974+00	1
\.


--
-- Name: Task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."Task_id_seq"', 5, true);


--
-- Name: UserTask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."UserTask_id_seq"', 31, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."User_id_seq"', 13, true);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY ("id");


--
-- Name: UserTask UserTask_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."UserTask"
    ADD CONSTRAINT "UserTask_pkey" PRIMARY KEY ("id");


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY ("id");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."_prisma_migrations"
    ADD CONSTRAINT "_prisma_migrations_pkey" PRIMARY KEY ("id");


--
-- Name: UserTask_userId_taskId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserTask_userId_taskId_key" ON "public"."UserTask" USING "btree" ("userId", "taskId");


--
-- Name: User_referredBy_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_referredBy_idx" ON "public"."User" USING "btree" ("referredBy");


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON "public"."User" USING "btree" ("username");


--
-- Name: UserTask UserTask_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."UserTask"
    ADD CONSTRAINT "UserTask_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "public"."Task"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserTask UserTask_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."UserTask"
    ADD CONSTRAINT "UserTask_userId_fkey" FOREIGN KEY ("userId") REFERENCES "public"."User"("id") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_referredBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."User"
    ADD CONSTRAINT "User_referredBy_fkey" FOREIGN KEY ("referredBy") REFERENCES "public"."User"("username") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

